S29GL064N Dual Flash driver for Keil MCB1800 / MCB4300 board
=============================================================

This project provides all files required to build a flash driver
for the S29GL064N 16MB flash fitted onto the Keil MCB1800 / MCB4300 board.

The code is based on the Flash driver sources provided in the
LPC18xxA Peripheral Driver Library 
[RELEASE CMSIS for REV A 20111209]
which is available from http://www.lpcware.com/

The project configuration provided....
        
FlashDriver_16MB - produces an actual flash driver (.cfx) file for use
        by Red Suite to program a project into flash.