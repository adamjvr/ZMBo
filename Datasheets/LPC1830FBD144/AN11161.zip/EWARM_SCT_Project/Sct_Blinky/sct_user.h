#ifndef __SCT_USER_H__
#define __SCT_USER_H__
#include "LPC18xx.h"

#define speed (65535)
#endif
