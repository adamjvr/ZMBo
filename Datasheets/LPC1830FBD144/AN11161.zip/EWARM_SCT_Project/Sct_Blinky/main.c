/*
===============================================================================
 Name        : main.c
 Author      : 
 Version     :
 Copyright   : Copyright (C) 
 Description : main definition
===============================================================================
*/

#ifdef __USE_CMSIS
#include "LPC18xx.h"
#endif

int sct_main (void);

int main(void) {

	sct_main();

	while(1) {
	}
}
